package com.jspiders.skyleaf.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.skyleaf.beans.CardExpiry;

public interface CardExpiryRepository extends CrudRepository<CardExpiry, String> {

}
