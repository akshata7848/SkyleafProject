package com.jspiders.skyleaf.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.skyleaf.beans.Card;

public interface CardRepository extends CrudRepository<Card, String>{

}
